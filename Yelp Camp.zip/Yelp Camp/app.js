var express=require("express");
var app=express();
var BodyParser=require("body-parser");

app.use(BodyParser.urlencoded({extended : true}))

const port= 9000;
var camppeople=[
    {name: "Ashish", image:"https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTbTxKKEznPC5r5pOIqFBvb3-dH7Uwr1vMKbbEfwYO_wnNaN0Jb&usqp=CAU"},
    {name:"Angad", image:"https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSUTOFWXvTQyZn3pVXpxmAc4uCpjVDu5XQq5yWrb2YvX34h0uHV&usqp=CAU"},
    {name:"parikshit hiremath", image:"https://pbs.twimg.com/media/CQkSp6KUkAEabD3.jpg"}
              ]


app.get("/",function(req,res){
    res.render("home.ejs");
});


app.get("/campground",function(req,res){
        res.render("camping.ejs",{camper:camppeople});
});

app.post("/campground",function(req,res){
    var name=req.body.names;
    var url= req.body.url;
    var obj={name : name , image :url};
    camppeople.push(obj);
    res.redirect("/campground");

});

app.get("/newcamp",function(req,res){
    res.render("new.ejs");
})


app.listen(port,function(){
    console.log("Roo mat");
});